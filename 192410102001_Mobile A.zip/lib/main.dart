import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  List<Map<String, dynamic>> list_kontak = [
    {
      'nama': 'Adit',
      'email': 'adit01@gmail.com',
      'nohp': '080001654321',
      'foto': 'adit.jpg',
    },
    {
      'nama': 'Oneng',
      'email': 'oneng16@gmail.com',
      'nohp': '080016654321',
      'foto': 'oneng.jpg',
    },
    {
      'nama': 'PowerRangers OfficialProductions',
      'email': 'powerangeroffice@gmail.com',
      'nohp': '080020654321',
      'foto': 'power.jpg',
    },
    {
      'nama': "Jarwo",
      'email': 'jarwo11@gmail.com',
      'nohp': '080011654321',
      'foto': 'jarwo.jpg',
    },
    {
      'nama': "Sopo",
      'email': 'sopo23@gmail.com',
      'nohp': '080023654321',
      'foto': 'sopo.jpg',
    },
    {
      'nama': "Joker",
      'email': 'joker12@gmail.com',
      'nohp': '080012654321',
      'foto': 'joker.jpg',
    },
    {
      'nama': "Avenger",
      'email': 'avenger03@gmail.com',
      'nohp': '080003654321',
      'foto': 'avenger.jpg',
    },
    {
      'nama': "Superman",
      'email': 'superman26@gmail.com',
      'nohp': '080026654321',
      'foto': 'superman.jpg',
    },
    {
      'nama': "Kaptenio Amerryika Seerikat Barat",
      'email': 'kapten13@gmail.com',
      'nohp': '080013654321',
      'foto': 'kapten.jpg',
    },
    {
      'nama': "Hulk",
      'email': 'hulk09@gmail.com',
      'nohp': '080009654321',
      'foto': 'hulk.jpg',
    },
    {
      'nama': "Flash Light Shine And Bright",
      'email': 'flash08@gmail.com',
      'nohp': '080008654321',
      'foto': 'flash.jpg',
    },
    {
      'nama': "Operatoriiia Telkomselll Syalalala",
      'email': 'operator17@gmail.com',
      'nohp': '080017654321',
      'foto': 'operator.jpg',
    },
    {
      'nama': "Elsa DoYouWannaBuiltASnowman",
      'email': 'elsa07@gmail.com',
      'nohp': '080007654321',
      'foto': 'elsa.jpg',
    },
    {
      'nama': "Petugas Vaksinasi Seluruh Dunia",
      'email': 'vaksin30@gmail.com',
      'nohp': '080030654321',
      'foto': 'vaksin.jpg',
    },
    {
      'nama': "Iron ManManmanmanman",
      'email': 'ironman10@gmail.com',
      'nohp': '080010654321',
      'foto': 'ironman.jpg',
    },
    {
      'nama': "Spiderman Temennya LabaLaba",
      'email': 'spiderman24@gmail.com',
      'nohp': '080024654321',
      'foto': 'spiderman.jpg',
    },
    {
      'nama': "Batman",
      'email': 'batman05@gmail.com',
      'nohp': '080005654321',
      'foto': 'batman.jpg',
    },
    {
      'nama': "Ultraman Tingtung Tingtung",
      'email': 'ultraman28@gmail.com',
      'nohp': '080028654321',
      'foto': 'ultraman.jpg',
    },
    {
      'nama': "Suneo Anak Mamamamama",
      'email': 'suneo25@gmail.com',
      'nohp': '080025654321',
      'foto': 'suneo.jpg',
    },
    {
      'nama': "Nobita Baju Kuningning",
      'email': 'nobita15@gmail.com',
      'nohp': '080015654321',
      'foto': 'nobita.jpg',
    },
    {
      'nama': "Saka Avatar of Aang",
      'email': 'saka21@gmail.com',
      'nohp': '080021654321',
      'foto': 'saka.jpg',
    },
    {
      'nama': "Ucup Kata Pak HAji",
      'email': 'ucup27@gmail.com',
      'nohp': '080027654321',
      'foto': 'ucup.jpg',
    },
    {
      'nama': "Unyil Usro dankawankawan",
      'email': 'unyil29@gmail.com',
      'nohp': '080029654321',
      'foto': 'unyil.jpg',
    },
    {
      'nama': "Pak Ogah Botak",
      'email': 'pakogah18@gmail.com',
      'nohp': '080018654321',
      'foto': 'pakogah.jpg',
    },
    {
      'nama': "Pak RAden Handikusumojoyo",
      'email': 'pakraden19@gmail.com',
      'nohp': '080019654321',
      'foto': 'pakraden.jpg',
    },
    {
      'nama': "Naruto",
      'email': 'naruto14@gmail.com',
      'nohp': '080014654321',
      'foto': 'naruto.jpg',
    },
    {
      'nama': "Sinchan Anak Mama Nohara",
      'email': 'sinchan22@gmail.com',
      'nohp': '080022654321',
      'foto': 'sinchan.png',
    },
    {
      'nama': "Doraemon LALALLAA",
      'email': 'doraemon06@gmail.com',
      'nohp': '080006654321',
      'foto': 'doraemon.png',
    },
    {
      'nama': "Barbie Bukan Boneka",
      'email': 'barbie04@gmail.com',
      'nohp': '080004654321',
      'foto': 'barbie.jpg',
    },
    {
      'nama': "Avatar The Legend of Aang",
      'email': 'avatar02@gmail.com',
      'nohp': '080002654321',
      'foto': 'avatar.jpg',
    },
  ];

  MyApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    list_kontak.sort((a, b) => a["nama"].compareTo(b["nama"]));

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: Text("Contacs")),
        body: ListView(
          children: [
            for (int index = 0; index < list_kontak.length; index++)
              Container(
                width: double.infinity,
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(10),
                height: 140,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(color: Colors.grey.withOpacity(0.5), spreadRadius: 5, blurRadius: 7, offset: Offset(0, 3))
                  ],
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundImage: AssetImage('lib/images/${list_kontak[index]["foto"]}'),
                      radius: 30,
                    ),
                    Flexible(
                      fit: FlexFit.tight,
                      child: Container(
                          margin: EdgeInsets.all(25),
                          width: 100,
                          height: 120,
                          color: Colors.white,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "${list_kontak[index]['nama']}",
                              ),
                              Text(
                                "${list_kontak[index]['email']}",
                              ),
                              Text(
                                "${list_kontak[index]['nohp']}",
                              ),
                            ],
                          )),
                    )
                  ],
                ),
              )
          ],
        ),
      ),
    );
  }
}
